import React from 'react'
import '../../assets/css/Home.css'
import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'


function Assign() {
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
   

    </div>
    </>
  )
}

export default Assign;