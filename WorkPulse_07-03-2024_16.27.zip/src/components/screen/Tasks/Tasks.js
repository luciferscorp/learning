import React from 'react'

import Navbar from '../../common/Navbar'
import Sidebar from '../../common/Sidebar'


function Tasks() {
  return (
    <>
    <div className='home-body'>

      <Navbar />
      <Sidebar />
   

    </div>
    </>
  )
}

export default Tasks;