import { dblClick } from '@testing-library/user-event/dist/click';
import { App } from 'antd'
import ErrorList from 'antd/es/form/ErrorList';
import React from 'react'
import Addproject from '../../common/AddProjects';




function Test() {


  return (
    <div>
      <Addproject />
    </div>

  );

}


export default Test