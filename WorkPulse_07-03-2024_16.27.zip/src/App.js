import React from "react";
import { createBrowserRouter, RouterProvider, BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './components/screen/Home/Home.js'
import RegisterPage from './components/screen/Register/Register.js'
import LoginPage from "./components/screen/Login/Login.js";

import Admin from "./components/screen/Admin/Admin.js";
import Assign from "./components/screen/Assign/Assign.js";
import Employee from "./components/screen/Employee/Employee.js";
import Company from "./components/screen/Company/Company.js";
import ProjectManager from "./components/screen/ProjectManager/ProjectManager.js";
import Projects from "./components/screen/Projects/Projects.js";
import Tasks from "./components/screen/Tasks/Tasks.js";
import Test from "./components/screen/Test/Test.js";
import Logout from "./components/common/Logout.js";




function App() {

  const router = createBrowserRouter([
    {
      path: "/home",
      element: <Home />,
    },
    {
      path: "/",
      element: <LoginPage />,
    },
    {
      path: "/login",
      element: <LoginPage />,
    },
    {
      path: "/register",
      element: <RegisterPage />,
    },
    {
      path: "/admin",
      element: <Admin />,
    },
    {
      path: "/assign",
      element: <Assign />,
    },
    {
      path: "/employee",
      element: <Employee />,
    },
    {
      path: "/company",
      element: <Company />,
    },
    {
      path: "/projectmanager",
      element: <ProjectManager />,
    },

    {
      path: "/projects",
      element: <Projects />,
    },
    {
      path: "/tasks",
      element: <Tasks />,
    },
    {
      path: "/test",
      element: <Test />,
    },
    {
      path: "/logout",
      element: <Logout />,
    },
  ]);

  return (
    <RouterProvider router={router} />
  );
}

export default App;
