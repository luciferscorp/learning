import ReactDOM from "react-dom/client";

import '../../asserts/css/Layout.css'


import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="../Login/Login.js">Blogs</Link>
          </li>
          <li>
            <Link to="../Register/Register.js">Register</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Layout;