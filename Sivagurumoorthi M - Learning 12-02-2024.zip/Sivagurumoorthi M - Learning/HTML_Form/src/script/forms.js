
    function errorMessage() {

        var error = document.getElementById("error");
        //for username
        var username = document.getElementById("username");
        if (username.value === "") {
            error.textContent = "Enter your name"
        } else if (!isNaN(username.value)) {
            error.textContent = "Name should not be with numbers"
        }
        else {
            error.textContent = ""
        }


        

        event.preventDefault();
    }