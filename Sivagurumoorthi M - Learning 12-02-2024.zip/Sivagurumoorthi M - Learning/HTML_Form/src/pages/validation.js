function errorMessage() {

    var error = document.getElementById("error");
    var username = document.getElementById("username");
    if (username.value === "") {
        error.textContent = "Enter your name"
    } else if (!isNaN(username.value)) {
        error.textContent = "Name should not be with numbers"
    } else {
        error.textContent = ""
    }


    var email = document.getElementById("email");
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email.value.match(mailformat)) {
        error.textContent = "Valid Email"
    } else {
        error.textContent = "Invalid Email"
    }
    var password = document.getElementById("password");
    if (password.value === "") {
        error.textContent = "Enter you password"
    } else {
        error.textContent = ""
    }

    
    var password = document.getElementById("password");
    var re_pass = document.getElementById("re-pass");
    if (password.value === "") {
        error.textContent = "Re-enter you password"
    } else if (password.value != re_pass.value) {
        error.textContent = "Password does't match"
    }
    else {
        error.textContent = ""
    }
    event.preventDefault();
}




function validateName() {

    var error = document.getElementById("error");
    //for username
    var username = document.getElementById("username");
    if (username.value === "") {
        error.textContent = "Enter your name"
    } else if (!isNaN(username.value)) {
        error.textContent = "Name should not be with numbers"
    }
    else {
        error.textContent = ""
    }
    event.preventDefault();
}

function validateEmail() {
    var email = document.getElementById("email");
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email.value.match(mailformat)) {
        error.textContent = "Valid Email"
    } else {
        error.textContent = "Invalid Email"
    }
    event.preventDefault();
}

function validatePassword() {
    var password = document.getElementById("password");
    if (password.value === "") {
        error.textContent = "Enter you password"
    } else {
        error.textContent = ""
    }
    event.preventDefault();
}
function validateRePassword() {
    var password = document.getElementById("password");
    var re_pass = document.getElementById("re-pass");
    if (password.value === "") {
        error.textContent = "Re-enter you password"
    } else if (password.value != re_pass.value) {
        error.textContent = "Password does't match"
    }
    else {
        error.textContent = ""
    }
    event.preventDefault();
}

event.preventDefault();

